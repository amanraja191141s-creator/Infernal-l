# QA results — v98.63.9.25

- Focused release suite (`npm test`): **53/53 passed, 0 failed**.
- Android web bundle (`npm run build:web`): **PASS**, 13 required assets verified and copied.
- JavaScript syntax checks (`assets/js/app.js`, `service-worker.js`): **PASS**.
- Workflow regression checks: **PASS** for exact source/version identity, SDK setup, pinned SDK packages, generated `www/` asset paths, build ordering and APK artifact verification.
- APK build: **NOT RUN** in this environment. `npm install` timed out and Android SDK/Gradle tooling is unavailable here.
- GitHub Actions workflow is configured to provision Android SDK API 35 / Build Tools 35.0.0, build `assembleDebug`, validate APK identity and upload the APK; failure diagnostics are also uploaded when available.

The debug APK is not represented as ready until the workflow has produced and uploaded the artifact successfully.
- Full historical suite (`npm run test:legacy`): **369/440 passed, 71 failed**. Failures span older release-version assertions and legacy architecture expectations (including previous standalone/split scientific-screen assumptions). They are recorded as unresolved historical regression debt; they are not counted as current release-gate passes.
