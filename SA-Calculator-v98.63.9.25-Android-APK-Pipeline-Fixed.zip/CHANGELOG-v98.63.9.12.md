# SA Calculator v98.63.9.12 — Change Log

## Calculator-first layout
- Made the standard calculator the primary launch/workspace surface.
- Removed the global app header while the calculator is active to reclaim usable vertical space.
- Renamed the primary bottom navigation label from “Home” to “Calculator”.
- Kept the calculator expression and preview/result display at 46% of the active workspace and the five-row keypad at 54%, with small-height responsive overrides retained.
- Preserved keypad controls, bottom navigation, tools, history, favorites and settings.

## Converter decluttering
- Currency converter: removed descriptive card headings, refresh caption, rate notes, provider/status and refresh-time copy from the compact input surface.
- Kept selected currency identity, amount fields, swap control, refresh action and accessible control labels.
- Unit converter: removed card headings and helper note while preserving category/from/to selectors, selected values, amount/result, swap and Convert action.
- Kept the actual selectable options available in the picker; only the always-visible explanatory text was removed.

## Build
- Updated Android workflow display name to v98.63.9.12 while retaining the project's established package/version identity and versionCode expected by the existing release gate.
- Regenerated the Android web bundle from the canonical source stylesheet.
