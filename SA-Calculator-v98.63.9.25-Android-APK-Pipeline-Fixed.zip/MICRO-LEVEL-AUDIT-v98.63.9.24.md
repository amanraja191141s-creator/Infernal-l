# Micro-level audit — v98.63.9.24

## Reference review
Reviewed the uploaded `Screenrecording_20261121_105842.mp4` (17.93 seconds). The scientific function surface is shown as a clean 4-column × 4-row panel: no individual key outlines, no helper captions above/below labels, and a pink panel surface. The ordinary calculator display remains above the function panel.

## Implemented
- Removed key borders, boxed gradients, shadows and `data-sci-hint` pseudo-labels from the visible 16-key matrix.
- Applied a pink drawer surface with subtle darker side accents and dark, legible function labels.
- Kept the 4×4 grid, INV one-shot interaction, More button, and existing function insertion behavior.
- Hid duplicate scientific display/toolbar/memory/numeric keypad rows from the visible drawer. The standard calculator display and standard keypad remain in place.
- Moved scientific angle, cursor, delete, clear, history, close and memory controls into the expandable More panel.
- Preserved the scientific engine, token parsing, main-expression insertion path, and drawer gesture handling.
- Added regression tests for the visual contract, control reachability and synchronized release identity.

## Verification
See `QA-RESULTS-v98.63.9.24.md` for commands and outcomes.

## Not certified
No native APK was installed on a physical Android device during this run. Device-specific rendering, touch latency, frame pacing, ad-layout interaction and OEM gesture behavior remain unverified. Therefore this release is not represented as physically device-certified or guaranteed bug-free on every device.
