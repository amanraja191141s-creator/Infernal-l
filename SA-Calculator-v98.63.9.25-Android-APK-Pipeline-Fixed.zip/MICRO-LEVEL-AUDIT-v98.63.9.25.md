# Micro-level audit — v98.63.9.25

## Confirmed root causes in v98.63.9.24

1. The Android web-bundle verification array contained `assets/brand/sa-home-neon-wave.svg` without the `www/` prefix. The build script copies the asset to `www/assets/brand/sa-home-neon-wave.svg`, so the workflow's relative path check failed even after a successful web bundle build.
2. Android SDK provisioning was only checked, not installed or pinned. A runner image without the required API/build-tools package could fail later during Gradle configuration or resource processing.
3. The local `android:apk` script did not apply the native branding/version patch before invoking Gradle, unlike the GitHub Actions path.
4. Android workflow checks were not adequately represented in the active focused release test suite; the old readiness test contained stale version assertions.

## Fixes

- All generated web asset checks now point inside `www/`; each entry is regression-tested against the corresponding source asset.
- Added Android SDK setup and explicit installation of platform-tools, Android API 35 and Build Tools 35.0.0; checks the pinned `aapt` executable before build.
- Aligned package / app / HTML / PWA / cache / workflow / APK version identity at `1.98.73-v98.63.9.25`, Android versionCode `1098073`.
- Updated local APK command to build web assets, sync Capacitor, apply native branding and then assemble the debug APK.
- Added tests that enforce source identity, SDK setup, generated asset path correctness, build order, APK validation and artifact upload.
- Added failure diagnostics artifact upload for Android build reports and Gradle daemon logs.

## Verification performed in this environment

- `npm test`: 53/53 focused release tests passed.
- `npm run build:web`: passed; all 13 required web assets verified and copied.
- `node --check assets/js/app.js`: passed.
- `node --check service-worker.js`: passed.
- Workflow YAML parsing: PASS. All 38 required source files exist. All 13 generated Android assets exist after web build and are rooted under `www/`. Package / HTML / runtime / manifest identity is synchronized.
- Full historical suite: 369/440 passed, 71 failed; legacy failures remain unresolved and are listed in QA results.

## Not verified here

This environment did not complete `npm install` (network/dependency installation timed out) and has no Android SDK / Gradle Android project installed. Therefore `npx cap add android`, `npx cap sync android`, Gradle `assembleDebug`, APK signing/identity inspection and device installation were not executed here. The workflow is repaired and regression-tested, but a real APK artifact can only be confirmed after the GitHub Actions run completes successfully. No claim of a locally built APK or physical-device certification is made.
