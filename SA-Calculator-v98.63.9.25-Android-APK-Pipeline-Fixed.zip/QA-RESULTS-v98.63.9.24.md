# QA results — v98.63.9.24

- Focused release regression suite (`npm test`): **48/48 passed, 0 failed**.
- Web bundle build (`npm run build:web`): **PASS**, 13 required assets verified.
- `node --check assets/js/app.js`: **PASS**.
- `node --check service-worker.js`: **PASS**.
- `node --check www/assets/js/app.js`: **PASS**.
- Android workflow YAML parse: **PASS**.
- HTML ID audit: **274 IDs, 0 duplicates**.
- Package, HTML, runtime, manifest, service-worker and workflow release identity: **synchronized** (`1.98.72-v98.63.9.24`, versionCode `1098072`).

## Historical test suite
`npm run test:legacy`: **365/438 passed, 73 failed**. This broad historical suite contains many fixed-version assertions and architecture checks from earlier releases, some of which conflict with the current scientific-drawer architecture. Not all 73 failures have been individually proven obsolete; treat this suite as unresolved historical debt, not a clean pass.

## Manual/device limitations
No physical Android device or emulator session was available for this run. Visual fidelity is based on the uploaded screen recording and source-level regression assertions; actual device screenshot parity, touch latency, frame pacing, ad-layout interaction and OEM gesture behavior remain unverified. This release is not represented as physically device-certified or guaranteed bug-free on every device.
