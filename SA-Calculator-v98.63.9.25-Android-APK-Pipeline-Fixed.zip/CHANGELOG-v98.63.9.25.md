# Changelog — v98.63.9.25

## Android debug APK pipeline repair

- Corrected the generated Android web asset verification path so every generated asset is checked under `www/`; removed the duplicate wave-asset entry.
- Added explicit Android SDK setup and pinned Android API 35 / Build Tools 35.0.0 provisioning before the native build.
- Synchronized package, HTML, runtime, PWA manifest, service-worker cache namespace, workflow source selector, APK version name and Android version code (`1098073`).
- Strengthened the release gate with dedicated Android workflow regression tests for source identity, SDK provisioning, web bundle paths, build-step order and APK artifact verification.
- Updated the local `android:apk` script to apply native branding/version metadata before Gradle assembly.
- Added failure-only diagnostics artifact upload so Gradle reports and daemon logs can be inspected when an APK build fails.
- Preserved the existing calculator, scientific drawer, tools and UI behavior; this release is focused on Android packaging and CI reliability.
