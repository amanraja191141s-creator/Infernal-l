# Changelog — v98.63.9.23

- Corrected initial scientific DEG/RAD button label to reflect the persisted angle preference before the first interaction.
- Exposed the current angle mode through `aria-label` and `aria-pressed`, and kept those states synchronized after toggling.
- Preserved 48px minimum scientific primary and More-panel touch targets on short-height displays; the scientific workspace scrolls when vertical space is constrained.
- Added visible keyboard focus treatment for tool cards and scientific controls.
- Bumped app, PWA, service-worker cache and Android workflow identity together.
- Added targeted regression tests for initial angle state, accessible state synchronization, short-screen touch targets and focus visibility.
