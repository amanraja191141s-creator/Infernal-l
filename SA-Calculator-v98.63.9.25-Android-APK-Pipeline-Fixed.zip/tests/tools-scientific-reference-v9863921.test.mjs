import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html', 'utf8');
const js = fs.readFileSync('assets/js/app.js', 'utf8');
const css = fs.readFileSync('assets/css/app.css', 'utf8');

test('Other Calculator uses the recording-matched grouped three-column tool catalogue', () => {
  const start = html.indexOf('id="premium-tools-grid"');
  const end = html.indexOf('</div>', start);
  const catalogue = html.slice(start, html.indexOf('</section>', start));
  assert.match(catalogue, /Finance &amp; Money|Finance & Money/);
  assert.match(catalogue, /Math &amp; General Utilities|Math & General Utilities/);
  assert.match(catalogue, /data-tools-group/);
  assert.match(css, /#screen-tools \.tools-reference-grid[\s\S]*?repeat\(3,minmax\(0,1fr\)\)/);
  const ids = [...catalogue.matchAll(/data-tool-screen="([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 16);
  assert.equal(new Set(ids).size, 16);
  assert.match(js, /toolsGrid\?\.addEventListener\('click'/);
});

test('Unit Converter opens on category tiles and retains the working conversion workspace', () => {
  assert.match(html, /id="unit-category-chooser"/);
  assert.match(html, /id="unit-converter-workspace" hidden/);
  assert.match(html, /data-unit-category="length"/);
  assert.match(html, /data-unit-category="temperature"/);
  assert.match(html, /id="unit-category-back"/);
  assert.match(js, /showUnitWorkspace\(tile\.dataset\.unitCategory\)/);
  assert.match(js, /showUnitCategories/);
  assert.match(js, /catSel\.dispatchEvent\(new Event\('change'/);
  assert.match(css, /#screen-units \.unit-category-grid[\s\S]*?repeat\(3,minmax\(0,1fr\)\)/);
});

test('Scientific INV control has one unique id and remains in the 4x4 function matrix', () => {
  assert.equal((html.match(/id="sci-shift-toggle"/g) || []).length, 1);
  const grid = html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0] || '';
  assert.equal((grid.match(/<button\b/g) || []).length, 16);
  assert.match(grid, /id="sci-shift-toggle"/);
  assert.match(js, /event\.target\.closest\('#sci-shift-toggle'\)/);
});

test('INV is a one-shot modifier and restores primary labels after an inverse function key', () => {
  assert.match(js, /const shiftActive = shift\?\.getAttribute\('aria-pressed'\) === 'true'/);
  assert.match(js, /if \(shiftActive && key\.dataset\.sciAltInsert\)/);
  assert.match(js, /button\.textContent = button\.dataset\.sciLabel \|\| button\.dataset\.sciInsert/);
  for (const token of ['asin(', 'acos(', 'atan(', '2.718281828459045^(', 'log2(']) assert.ok(html.includes(`data-sci-alt-insert="${token}"`), token);
});
