import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('scientific panel is a keypad-level split drawer, not a full-screen overlay', () => {
  assert.match(html, /id="screen-calc"[\s\S]*?<section class="scientific-screen scientific-drawer" id="screen-scientific"/);
  assert.match(css, /#screen-calc\.scientific-split-open \.main-keypad\s*\{[\s\S]*?width:46%/);
  assert.match(css, /#screen-calc #screen-scientific\.scientific-drawer\s*\{[\s\S]*?height:64%/);
  assert.match(css, /width:54%/);
  assert.match(css, /#app-container > #screen-viewport > #screen-calc\.active\.scientific-split-open > \.main-keypad[\s\S]*?width:46%/);
});
test('scientific drawer shows function pad only; no duplicate calculator display or number pad', () => {
  assert.match(css, /#screen-calc #screen-scientific \.scientific-keypad[\s\S]*?display:none!important/);
  assert.match(css, /#screen-calc #screen-scientific \.scientific-expression[\s\S]*?display:none!important/);
  assert.match(css, /scientific-function-grid[\s\S]*?grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(html, /id="sci-more-toggle"/);
  assert.match(css, /grid-template-rows:repeat\(4,minmax\(0,1fr\)\)/);
});
test('function keys insert into the main calculator expression engine', () => {
  assert.match(js, /const insertScientificIntoMain = token =>/);
  assert.match(js, /key\.closest\('\.scientific-function-grid, \.scientific-more-functions'\)\) insertScientificIntoMain\(token\)/);
  assert.match(js, /STATE\.calcAngleMode = sci\.angle/);
  assert.ok(js.includes("event.target.closest('.main-keypad, .calc-edit-action, .scientific-function-grid, .scientific-more-functions')"));
  assert.match(js, /evaluateArithmetic\(clean, STATE\.implicitMult, STATE\.calcAngleMode \|\| 'deg'\)/);
});
test('primary scientific matrix matches the 4×4 reference and exposes More', () => {
  const grid = html.match(/<div class=\"scientific-function-grid\"[\s\S]*?<\/div>/)?.[0] || '';
  const buttons = (grid.match(/<button\b/g) || []).length;
  assert.equal(buttons, 16);
  assert.match(grid, /id=\"sci-more-toggle\"/);
});
test('open and close states update both drawer and keypad split classes', () => {
  assert.match(js, /calcScreen\?\.classList\.add\('scientific-split-open'\)/);
  assert.match(js, /calcScreen\?\.classList\.remove\('scientific-split-open'\)/);
  assert.match(js, /x >= width - 44/);
  assert.match(js, /if \(!start\.open && dx < 0\) openDrawer\(\)/);
  assert.match(js, /else if \(start\.open && dx > 0\) closeDrawer\(false\)/);
});
test('separate scientific tool/favorite destination is removed', () => {
  assert.doesNotMatch(js, /\{ id: 'scientific', name: 'Scientific Calculator' \}/);
  assert.doesNotMatch(html, /data-tool-screen="scientific"/);
});
test('release identity is synchronized', () => {
  assert.equal(pkg.version, '1.98.67-v98.63.9.19');
  assert.match(html, /v98\.63\.9\.19/);
});

test('service-worker cache identity and Android workflow use the current split-panel release', () => {
  const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.match(sw, /v9863919-sci-split/);
  assert.match(workflow, /v9863919-sci-split/);
  assert.match(workflow, /versionCode='1098067'/);
});
