const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = process.cwd();
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const workflow = read('.github/workflows/main.yml');
const pkg = JSON.parse(read('package.json'));

test('Android workflow pins the exact source and synchronized APK identity', () => {
  assert.equal(pkg.version, '1.98.73-v98.63.9.25');
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.73-v98\.63\.9\.25'/);
  assert.match(workflow, /versionName='1\.98\.73-v98\.63\.9\.25'/);
  assert.match(workflow, /versionCode='1098073'/);
  assert.match(workflow, /SA-Calculator-Debug-APK-\$\{\{ steps\.locate\.outputs\.app_version \}\}/);
  assert.match(workflow, /uses: actions\/upload-artifact@v4/);
});

test('Android SDK is provisioned explicitly and pinned platform/build-tools are installed', () => {
  assert.match(workflow, /uses: android-actions\/setup-android@v3/);
  assert.match(workflow, /sdkmanager --install "platform-tools" "platforms;android-35" "build-tools;35\.0\.0"/);
  assert.match(workflow, /test -x "\$SDK\/build-tools\/35\.0\.0\/aapt"/);
});

test('generated web bundle validation checks only paths that actually exist under www', () => {
  const block = workflow.match(/required_assets=\(\n([\s\S]*?)\n          \)/);
  assert.ok(block, 'required_assets array missing');
  const entries = [...block[1].matchAll(/^\s+([^\s]+)\s*$/gm)].map(m => m[1]);
  assert.ok(entries.length >= 13);
  for (const entry of entries) {
    assert.ok(entry.startsWith('www/'), `generated asset path must be under www/: ${entry}`);
    const sourcePath = entry.slice(4);
    assert.ok(fs.existsSync(path.join(root, sourcePath)), `source for generated asset missing: ${sourcePath}`);
  }
  assert.equal(entries.filter(x => x === 'www/assets/brand/sa-home-neon-wave.svg').length, 1);
});

test('APK build is gated by web build, release tests, Capacitor sync and Gradle assembleDebug', () => {
  const ordered = [
    'npm run build:web',
    'npm run test:release',
    'npx cap sync android',
    'npm run android:brand',
    './gradlew --no-daemon --stacktrace assembleDebug'
  ];
  let previous = -1;
  for (const marker of ordered) {
    const at = workflow.indexOf(marker);
    assert.ok(at > previous, `workflow step missing or out of order: ${marker}`);
    previous = at;
  }
  assert.match(workflow, /test -s "\$APK"/);
  assert.match(workflow, /unzip -tq "\$APK"/);
  assert.match(workflow, /if-no-files-found: error/);
});

test('Android native branding and build scripts are present and package identity is derived safely', () => {
  const scripts = pkg.scripts;
  assert.match(scripts['android:apk'], /npm run build:web && npx cap sync android && npm run android:brand && cd android && \.\/gradlew --no-daemon assembleDebug/);
  assert.ok(fs.existsSync(path.join(root, 'scripts/prepare-android-web.mjs')));
  assert.ok(fs.existsSync(path.join(root, 'scripts/patch-android-native.mjs')));
  assert.ok(fs.existsSync(path.join(root, 'capacitor.config.json')));
});
