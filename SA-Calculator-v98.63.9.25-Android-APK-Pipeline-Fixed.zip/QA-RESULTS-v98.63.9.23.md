# QA results — v98.63.9.23

## Focused release gate
- Node release tests: **46/46 passed, 0 failed**.
- JavaScript source syntax: PASS (`assets/js/app.js`).
- Service worker syntax: PASS (`service-worker.js`).
- Android web bundle generation: PASS — 13 required assets verified.
- Generated Android web JavaScript syntax: PASS.
- GitHub Actions workflow YAML parse: PASS.
- HTML ID uniqueness: PASS — 274 IDs, no duplicates.
- Package, HTML, runtime, manifest, service-worker cache and Android workflow identity: synchronized (`1.98.71-v98.63.9.23`, versionCode `1098071`).

## New regression coverage
- Persisted DEG/RAD preference initializes the visible angle button correctly.
- Angle mode accessible label and pressed state stay synchronized after changes.
- Scientific primary and More-panel buttons retain 48px minimum targets on short-height layouts.
- Tool and scientific controls have visible keyboard focus indicators.
- Existing grouped three-column Tools catalogue, 16 destinations, scientific 4×4 matrix, INV behavior, drawer gestures and calculator arithmetic remain covered.

## Full historical suite
- **359/436 passed; 77 failed.** The failures include many assertions pinned to older release identities, previous scientific-screen architectures, older CSS/build expectations and older workflow layouts. They have not all been proven obsolete; they remain outside the focused release gate and should not be represented as passing.

## Not certified
- Native Android APK build/install, emulator screenshot parity, physical-device rendering, touch latency, frame pacing and OEM gesture compatibility were not run in this environment.
